test = {'name': 'q1',
 'points': 16,
 'suites': [{'cases': [{'code': '>>> same_digits(2002200, 2202000) # Ignoring '
                                'repeats, both are 2020\n'
                                'True\n'
                                '\n'
                                '>>> same_digits(21, 12) # Digits must appear '
                                'in the same order\n'
                                'False\n'
                                '\n'
                                '>>> same_digits(12, 2212) # 12 and 212 are '
                                'not the same\n'
                                'False\n'
                                '\n'
                                '>>> same_digits(2020, 20) # 2020 and 20 are '
                                'not the same\n'
                                'False\n'}],
             'scored': True,
             'setup': 'from q1 import *',
             'type': 'doctest'}]}